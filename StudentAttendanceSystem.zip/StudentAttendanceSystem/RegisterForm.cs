﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAttendanceSystem
{
    public partial class RegisterForm : Form
    {
        TeacherDataStore dataStore = new TeacherDataStore();
        public RegisterForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataStore.Teachers.Add(new Teacher
            {
                Username = textBoxUsername.Text,
                Password = textBoxPassword.Text,
                Phone = textBoxPhone.Text,
                QuestionIndex = comboBox1.SelectedIndex,
                SecureAnswer = textBoxAnswer.Text,
            });
            dataStore.SaveData();
            DialogResult = DialogResult.OK;
            Close();
        }

        private void RegisterForm_Load(object sender, EventArgs e)
        {
            dataStore.LoadData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}
