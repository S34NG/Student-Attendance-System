﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAttendanceSystem
{
    public partial class LoginForm : Form
    {
        TeacherDataStore tds = new TeacherDataStore();
        public LoginForm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tds.LoadData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var res = tds.Teachers.Find(
                t => t.Username == textBoxUsername.Text
                && t.Password == textBoxPassword.Text);
            
            if (res == null)
            {
                MessageBox.Show("Invalid username or password.");
            }
            else
            {
                new DashboardForm(res).Show();
                Hide();
            }
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            RegisterForm f = new RegisterForm();
            DialogResult res = f.ShowDialog();
            if (res == DialogResult.OK)
            {
                tds.LoadData();//reload data
            }
        }
    }
}
