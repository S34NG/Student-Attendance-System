﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace StudentAttendanceSystem
{
    class TeacherDataStore
    {
        public List<Teacher> Teachers { get; set; } = new List<Teacher>();
        readonly string filename;
        public TeacherDataStore(string filename = "teachers.xml")
        {
            this.filename = filename;
        }
        public void LoadData()
        {
            if (!File.Exists(filename)) return;
            XmlSerializer serializer = new XmlSerializer(
                typeof(List<Teacher>));
            using(Stream stream = File.OpenRead(filename))
            {
                Teachers = (List<Teacher>)serializer.Deserialize(stream);
            }
        }
        public void SaveData()
        {
            XmlSerializer serializer = new XmlSerializer(
                typeof(List<Teacher>));
            using (Stream stream = File.OpenWrite(filename))
            {
                try
                {
                    serializer.Serialize(stream, Teachers);
                }
                catch(Exception e) { Console.WriteLine(e.Message); }
            }
        }
    }
}
