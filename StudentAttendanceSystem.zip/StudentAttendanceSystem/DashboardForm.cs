﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace StudentAttendanceSystem
{
    public partial class DashboardForm : Form
    {
        public BindingSource Bs { get; set; }
        Teacher teacher;
        AttendanceDataStore dataStore;
        public DashboardForm(Teacher res)
        {
            InitializeComponent();
            teacher = res;
            dataStore = new AttendanceDataStore(teacher.Username);
            dateTimePicker1.MaxDate = DateTime.Today;
        }

        private void DashboardForm_Load(object sender, EventArgs e)
        {
            dataStore.LoadData();
            Bs = new BindingSource();
            foreach(var d in dataStore.Attendances)
            {
                Bs.Add(d);
            }
            dataGridView1.DataSource=Bs;
            dataGridView1.CellValueChanged += dataGridView1_CellValueChanged;
        }


        private void DashboardForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            var obj = (Attendance)Bs[e.RowIndex];
            new ImagePreviewDialog().ShowDialog(this, obj);
        }

        /// <summary>
        /// Mark attendance clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            Bs.Clear();
            var res = dataStore.Attendances.FindAll(
                attend=>attend.Subject == comboBoxSubject.SelectedItem.ToString()
                && (dateTimePicker1.Value-attend.Date).TotalDays==0
                && attend.Session == comboBoxSession.SelectedIndex
                );
            if(res.Count == 0)
            {
                Attendance at1,at2,at3;
                dataStore.Attendances.Add(at1 =new Attendance
                {
                    No = 1,
                    Avatar = Properties.Resources._default,
                    Name = "Dara",
                    Status = "Present",
                    Remark = "", 
                    Date = dateTimePicker1.Value, 
                    Subject=comboBoxSubject.SelectedItem.ToString(), 
                    Session= comboBoxSession.SelectedIndex
                });
                dataStore.Attendances.Add(at2=new Attendance
                {
                    No = 2,
                    Avatar = Properties.Resources._default,
                    Name = "Seang",
                    Status = "Present",
                    Remark = "",
                    Date = dateTimePicker1.Value,
                    Subject = comboBoxSubject.SelectedItem.ToString(),
                    Session = comboBoxSession.SelectedIndex
                });
                dataStore.Attendances.Add(at3=new Attendance
                {
                    No = 3,
                    Avatar = Properties.Resources._default,
                    Name = "Lincoln",
                    Status = "Present",
                    Remark = "",
                    Date = dateTimePicker1.Value,
                    Subject = comboBoxSubject.SelectedItem.ToString(),
                    Session = comboBoxSession.SelectedIndex
                });
                Bs.Add(at1);
                Bs.Add(at2);
                Bs.Add(at3);
            }
            else
            {
                foreach (var r in res) Bs.Add(r);
            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            dataStore.SaveData();
            MessageBox.Show(sender.GetType().FullName);
        }
    }

    public class Attendance:IXmlSerializable
    {
        public int No { get; set; }
        public Image Avatar { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
        public string Remark { get; set; }
        public string Subject { get; set; }
        public DateTime Date { get; set; } = DateTime.Today;
        public int Session { get; set; } = 0;

        public XmlSchema GetSchema()
        {
            return null;
        }
        private string ToBase64()
        {
            using (MemoryStream m = new MemoryStream())
            {
                Avatar.Save(m, Avatar.RawFormat);
                byte[] imageBytes = m.ToArray();

                // Convert byte[] to Base64 String
                string base64String = Convert.ToBase64String(imageBytes);
                return base64String;
            }
        }

        public void ReadXml(XmlReader reader)
        {
            //reader.MoveToContent();
            Console.WriteLine(reader.Name);
            reader.ReadStartElement();
            No = int.Parse(reader.ReadElementContentAsString());
            Avatar = Image.FromStream(new MemoryStream(Convert.FromBase64String(reader.ReadElementContentAsString())));
            Name = reader.ReadElementContentAsString();
            Status = reader.ReadElementContentAsString();
            Remark = reader.ReadElementContentAsString();
            Subject = reader.ReadElementContentAsString();
            Date = DateTime.Parse(reader.ReadElementContentAsString());
            Session = reader.ReadElementContentAsInt();
            reader.ReadEndElement();
        }

        public void WriteXml(XmlWriter writer)
        {
            writer.WriteElementString("No", No.ToString());
            writer.WriteElementString("Avatar", ToBase64());
            writer.WriteElementString("Name", Name);
            writer.WriteElementString("Status", Status);
            writer.WriteElementString("Remark", Remark);
            writer.WriteElementString("Subject", Subject);
            writer.WriteElementString("Date", Date.ToShortDateString());
            writer.WriteElementString("Session", Session.ToString());
        }
    }
    public enum Status
    {
        Present, Late, Absent
    }
}
