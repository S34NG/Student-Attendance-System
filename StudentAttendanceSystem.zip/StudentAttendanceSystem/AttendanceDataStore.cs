﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Xml.Serialization;

namespace StudentAttendanceSystem
{
    public class AttendanceDataStore
    {
        readonly string filename = "_attendances.xml";
        public List<Attendance> Attendances { get; set; } =
            new List<Attendance>();
        public AttendanceDataStore(string teacherName)
        {
            filename = teacherName + filename;
        }
        public void LoadData()
        {
            if (!File.Exists(filename)) return;
            XmlSerializer serializer = new XmlSerializer(
                typeof(List<Attendance>));
            using (Stream stream = File.OpenRead(filename))
            {
                Attendances = (List<Attendance>)serializer.Deserialize(stream);
            }
        }
        public void SaveData()
        {
            XmlSerializer serializer = new XmlSerializer(
                typeof(List<Attendance>));
            using (Stream stream = File.OpenWrite(filename))
            {
                try
                {
                    serializer.Serialize(stream, Attendances);
                }
                catch (Exception e) { Console.WriteLine(e.Message); }
            }
        }
    }
}